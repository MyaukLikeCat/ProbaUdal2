This proof demonstrates the memory safety of the TaskIncrementTick function.
No assumptions nor abstractions are required for single-threaded computation.

This proof is a work-in-progress.  Proof assumptions are described in
the harness.
